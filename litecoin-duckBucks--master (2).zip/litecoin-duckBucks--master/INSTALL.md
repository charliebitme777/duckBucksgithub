Building duckBucks
================

See doc/build-*.md for instructions on building the various
elements of the duckBucks Core reference implementation of duckBucks.
